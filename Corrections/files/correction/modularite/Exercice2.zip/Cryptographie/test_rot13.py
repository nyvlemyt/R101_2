import Cryptographie.rot13 as rot13


def test_chiffre_ROT13():
    assert rot13.chiffre_ROT13("") == ""
    assert rot13.chiffre_ROT13("!?") == "!?"
    assert rot13.chiffre_ROT13("hello WORLD") == "uryyb JBEYQ"
    assert rot13.chiffre_ROT13("uryyb JBEYQ") == "hello WORLD"



def test_dechiffre_ROT13():
    assert rot13.dechiffre_ROT13("") == ""
    assert rot13.dechiffre_ROT13("!?") == "!?"
    assert rot13.dechiffre_ROT13("hello WORLD") == "uryyb JBEYQ"
    assert rot13.dechiffre_ROT13("uryyb JBEYQ") == "hello WORLD"
